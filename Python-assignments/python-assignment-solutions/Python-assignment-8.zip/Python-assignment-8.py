#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


data = pd.read_csv('data.csv')


# In[3]:


data


# # problem statement - 1

# In[4]:


# Tasks To Be Performed:
# 1. Load the dataset using pandas
# 2. Extract data from years experience column is a variable named X
# 3. Extract data from the salary column is a variable named Y
# 4. Divide the dataset into two parts for training and testing in 66% and 33%
# proportion
# 5. Create and train Linear Regression Model on training set
# 6. Make predictions based on the testing set using the trained model
# 7. Check the performance by calculating the r2 score of the model.


# In[5]:


data.head()


# In[6]:


x = data['YearsExperience']


# In[7]:


x.head()


# In[8]:


print(type(x))


# In[9]:


x = pd.DataFrame(x)


# In[10]:


x.head()


# In[11]:


print(type(x))


# In[12]:


y = data['Salary']


# In[13]:


print(type(y))


# In[14]:


y = pd.DataFrame(y)


# In[15]:


y.head()


# In[16]:


from sklearn.model_selection import train_test_split


# In[17]:


x_train,x_test,y_train,y_test = train_test_split(x , y , train_size = 0.66 , random_state = 0)


# In[18]:


print(x_train.shape , x_test.shape , y_train.shape , y_test.shape)


# In[19]:


from sklearn.linear_model import LinearRegression


# In[20]:


LR = LinearRegression()


# In[21]:


LR.fit(x_train,y_train)


# In[22]:


prediction = LR.predict(x_test)


# In[23]:


prediction


# In[24]:


from sklearn.metrics import *


# In[25]:


r2_test = r2_score(y_test , prediction)


# In[26]:


r2_test


# # Problem statement -2

# In[27]:


# 1. Load the dataset using pandas
# 2. Extract data from outcome column is a variable named Y
# 3. Extract data from every column except outcome column in a variable
# named X
# 4. Divide the dataset into two parts for training and testing in 70% and 30%
# proportion
# 5. Create and train Logistic Regression Model on training set
# 6. Make predictions based on the testing set using the trained model
# 7. Check the performance by calculating the confusion matrix and accuracy
# score of the model.


# In[28]:


data = pd.read_csv("diabetes.csv")


# In[29]:


data.head()


# In[30]:


data.shape


# In[31]:


data.duplicated().sum()


# In[32]:


data.isnull().sum()


# In[33]:


data.info()


# In[34]:


# checking for outliers in every columns


# In[35]:


for col_name in data:    
    if data[col_name].dtypes == 'int64' or data[col_name].dtypes == 'float64':
        plt.boxplot(data[col_name])
        plt.xlabel(col_name)
        plt.ylabel('count')
        plt.show()


# In[36]:


# there are soe outliers in insulin column and DiabetesPedigreeFunction but since our data set is very small
# so i will not remove the outlier.


# In[37]:


x = data.drop(['Outcome'],axis = 1)


# In[38]:


y = data['Outcome']


# In[39]:


x


# In[40]:


y


# In[41]:


from sklearn.model_selection import train_test_split


# In[42]:


x_train , x_test , y_train,y_test = train_test_split(x , y , train_size = 0.70 , random_state = 0 )


# In[43]:


print(x_train.shape , x_test.shape , y_train.shape ,y_test.shape )


# In[44]:


from sklearn.linear_model import LogisticRegression


# In[45]:


LR = LogisticRegression()


# In[46]:


LR.fit(x_train , y_train)    # training the model


# In[47]:


prediction = LR.predict(x_test)


# In[48]:


prediction


# In[49]:


from sklearn.metrics import confusion_matrix , accuracy_score


# In[50]:


confusion_matrix(y_test , prediction)


# In[51]:


accuracy_score(y_test , prediction)


# # Problem statement -3

# In[52]:


# 1. Load the dataset using pandas
# 2. Extract data from outcome column is a variable named Y
# 3. Extract data from every column except outcome column in a variable
# named X
# 4. Divide the dataset into two parts for training and testing in 70% and 30%
# proportion
# 5. Create and train Decision Tree Model on training set
# 6. Make predictions based on the testing set using the trained model
# 7. Check the performance by calculating the confusion matrix and accuracy
# score of the model.


# In[53]:


# here sincee the starting four question is same so i am going to skip them.and directly build the Decision tree model.


# In[54]:


x.head()


# In[55]:


y.head()


# In[56]:


from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.metrics import confusion_matrix , accuracy_score


# In[57]:


x_train,x_test , y_train , y_test = train_test_split(x , y , train_size = 0.70 , random_state = 0)


# In[58]:


from sklearn.tree import DecisionTreeClassifier


# In[59]:


DTR = DecisionTreeClassifier()


# In[60]:


DTR.fit(x_train , y_train)


# In[61]:


prediction = DTR.predict(x_test)


# In[62]:


accuracy_score(y_test , prediction)


# In[63]:


print(classification_report(y_test , prediction))


# In[64]:


plt.figure(figsize = (30,30))
tree.plot_tree(DTR , feature_names = x.columns , class_names = 'target', filled = True)
plt.show()


# # Problem statement - 4

# In[65]:


# 1. Load the dataset using pandas
# 2. Extract data from outcome column is a variable named Y
# 3. Extract data from every column except outcome column in a variable
# named X
# 4. Divide the dataset into two parts for training and testing in 70% and 30%
# proportion
# 5. Create and train Random Forest Model on training set
# 6. Make predictions based on the testing set using the trained model
# 7. Check the performance by calculating the confusion matrix and accuracy
# score of the model.


# In[66]:


data = pd.read_csv('diabetes.csv')


# In[67]:


data.head()


# In[68]:


data.shape


# In[69]:


y = data['Outcome']


# In[71]:


x = data.drop(['Outcome'] , axis = 1)


# In[72]:


x_train,x_test,y_train,y_test = train_test_split(x,y,train_size=0.70 , random_state = 0)


# In[74]:


from sklearn.ensemble import RandomForestClassifier


# In[75]:


rfc = RandomForestClassifier()


# In[76]:


train = rfc.fit(x_train,y_train)


# In[77]:


predict = train.predict(x_test)


# In[78]:


accuracy_score(predict,y_test)


# # Problem-statement-5

# In[79]:


# 1. Load the dataset using pandas
# 2. Extract data from outcome column is a variable named Y
# 3. Extract data from every column except outcome column in a variable
# named X
# 4. Divide the dataset into two parts for training and testing in 70% and 30%
# proportion
# 5. Create and train Naïve Bayes Model on training set
# 6. Make predictions based on the testing set using the trained model
# 7. Check the performance by calculating the confusion matrix and accuracy
# score of the model


# In[80]:


# since question 1 to 4 is same i will directly start from question 5.


# In[81]:


x_train,x_test,y_train,y_test = train_test_split(x,y,train_size = 0.70 , random_state = 0)


# In[82]:


from sklearn.naive_bayes import GaussianNB

naive_bayes_model = GaussianNB()
naive_bayes_model.fit(x_train, y_train)


# In[83]:


Y_pred = naive_bayes_model.predict(x_test)


# In[85]:


accuracy = accuracy_score(y_test, Y_pred)


# In[86]:


accuracy


# In[ ]:




