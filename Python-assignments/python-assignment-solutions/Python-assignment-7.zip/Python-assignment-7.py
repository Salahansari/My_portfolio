#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd


# In[2]:


# 1. Using sklearn import the wine dataset
# 2. Split the data into train and test set
# 3. Train the model
# 4. Make Predictions
# 5. Check the performance of the model using r2 score.


# In[3]:


from sklearn.datasets import load_wine


# In[4]:


load_wines = load_wine()


# In[5]:


load_wines


# In[6]:


data = pd.read_csv("wine.csv")


# In[7]:


data


# In[8]:


data.info()


# In[9]:


data.shape


# In[10]:


data.duplicated().sum()


# In[11]:


data.isnull().sum()


# In[12]:


# no null values are present no duplicate data are present in wine data set


# In[13]:


data.describe()


# In[14]:


# 2. Split the data into train and test set


# In[15]:


# checking for the outliers in dataset


# In[16]:


import matplotlib.pyplot as plt


# In[17]:


for col_name in data:
    if data[col_name].dtypes== 'int64' or data[col_name].dtypes=='float64':
        plt.boxplot(data[col_name])
        plt.xlabel("col_name")
        plt.ylabel("Count")
        plt.show()


# In[18]:


from sklearn.model_selection import train_test_split


# In[19]:


x = data[['Wine','Alcohol','Malic.acid','Ash','Acl','Mg','Phenols','Flavanoids','Nonflavanoid.phenols','Proanth','Color.int','Hue','OD']]


# In[20]:


x


# In[21]:


y = data.iloc[ : , -1]


# In[22]:


y.head()


# In[23]:


x.shape


# In[24]:


# training the model


# In[25]:


x_train , x_test , y_train , y_test = train_test_split(x , y ,train_size = 0.80 , random_state = 0)


# In[26]:


print(x_train.shape)
print(y_train.shape)
print(x_test.shape)
print(y_test.shape)


# In[27]:


x_train , y_train ,x_test, y_test


# In[28]:


from sklearn.linear_model import LinearRegression


# In[29]:


LE = LinearRegression()


# In[30]:


# building the model
# 4. Make Predictions


# In[31]:


LE.fit(x_train , y_train)


# In[32]:


prediction = LE.predict(x_test)


# In[33]:


prediction


# In[34]:


from sklearn.metrics import *


# In[35]:


r2test = r2_score(y_test , prediction)


# In[36]:


r2test


# In[37]:


# Our model here is predicting the values 73.75% times right.


# In[ ]:




