#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Problem Statement:
# You work in XYZ Corporation as a Data Analyst. Your corporation has told you to
# visualize the mtcars.csv dataset with various plots.
# Dataset Link
# Tasks To Be Performed:
# 1. Start off by importing the cars.csv file in the jupyter notebook.
# 2. Generate a line plot graph for the column ‘model’ and ‘hp’
# a . Map the ‘model’ column on the x-axis
# b. Map the ‘hp’ column on the y-axis
# c. Provide the x-axis label as Models of the cars
# d. Provide the y-axis label as Horse-Power of Cars
# e. Set the title as Model Names vs HorsePower


# In[2]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


# In[3]:


cars = pd.read_csv('cars-1.csv')


# In[4]:


cars.head()


# In[5]:


cars.shape


# In[8]:


plt.figure(figsize = (5,10))
cars.plot(kind = 'line' , x = 'model' , y = 'hp')
plt.xlabel("Model of the car")
plt.ylabel("Horse-power of cars")
plt.xticks(rotation = 90)
plt.title("Model Names vs HorsePower")
plt.show()


# In[7]:


# Tasks To Be Performed:
# 1. Generate a bar plot graph for the columns ‘carbs’ and ‘gear’
# a. Map the ‘carbs’ onto the x-axis.
# b. Map the ‘gear’ onto the y-axis.
# c. Provide the x-axis label as Number of carburetors.
# d. Provide the y-axis label as Number of forward gears.
# e. Set the title as carbs vs gear.


# In[11]:


plt.figure(figsize = (10,6))
cars.plot(kind = 'bar' , x = 'carb' , y = 'gear')
plt.xlabel("Number of carburetors")
plt.ylabel("Number of forward gears")
plt.title("carbs vs gear")
plt.xticks(rotation = 90)
plt.show()


# In[12]:


# 1. Plot a histogram for the column ‘wt’
# a. Map the ‘wt’ onto the x-axis
# b. Provide the x-axis label as ‘weight of the cars’
# c. Provide the y-axis label as ‘Count’
# d. Set the number of bins as 30
# e. Set the title as ‘Histogram fot the weight values'.


# In[20]:


plt.figure(figsize = (10,6))
plt.hist(cars['wt'] , bins = 30 , color = 'black' , alpha =0.7)
plt.xlabel('weight of the cars')
plt.ylabel('Count')
plt.title('Histogram for the weight values')
plt.show()


# In[22]:


sns.histplot(data = cars , x= 'wt' ,bins = 30)


# In[23]:


# 1. Plot a pie chart for columns: ‘cyl’ and ‘model’ form the cars.csv data
# frame.


# In[24]:


cars.head()


# In[25]:


cyl_counts = cars['cyl'].value_counts()
model_counts = cars['model'].value_counts()


# In[28]:


plt.figure(figsize = (10,6))
plt.pie(cyl_counts, labels=cyl_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Pie Chart for Cylinder Counts')


# In[29]:


# Plot pie chart for 'model' column
plt.pie(model_counts, labels=model_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Pie Chart for Model Counts')

plt.tight_layout()
plt.show()


# In[ ]:




