#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Create a function named ‘factor’ that can only accept 1 argument. The
# function should return the factorial of that number.


# In[2]:


def factor(x):
    if x == 0 or x == 1:
        return 1
    else:
        return(x * factor(x-1))


# In[3]:


factor (2)


# In[4]:


factor(5)


# In[5]:


#  Create a function named ‘check_string’, the function should accept a string
# data from the user and the function should check if the user input contains
# the letter ‘s’ in it. If it contains the letter ‘s’ then print- ‘The string is
# containing the letter ‘s’’, if not then print- ‘The string doesn’t contain the
# letter ‘s’’.


# In[6]:


def check_string(input_string):
    if 's' in input_string or 'S' in input_string:
        print("The string is containg the letter S")
    else:
        print("The string doesn't contain the letter S")
        
# user input
user_input = input("Enter a string")
check_string(user_input)


# In[7]:


# Create a class named ‘student’ and inside the class, create a function
# named ‘fun1’- this method should accept the user defined input and return
# that value:
# a. Create another method named- message() and that method should print
# the user defined input that we have defined in ‘fun1’.


# In[8]:


class Student:
    def fun1(self, user_input):
        return user_input
    
    def message(self, input_value):
        print("User-defined input from 'fun1':", input_value)

# Creating an instance of the Student class
student_instance = Student()

# Taking user-defined input
user_input = input("Enter a value: ")

# Calling the 'fun1' method and storing the returned value
returned_value = student_instance.fun1(user_input)

# Calling the 'message' method to print the returned value
student_instance.message(returned_value)


# In[9]:


# Create a lambda function that should double or multiply the number (that
# we will be passing in the lambda function) by 2. Store the lambda function
# in a variable named 'double_num'.


# In[10]:


double_num = lambda x: x * 2 

double_num(8)


# In[11]:


# 5. Take user input string and check whether that string is palindrome or not.


# In[12]:


def is_palindrome(s):
    s = s.lower()  # Convert the string to lowercase
    s = s.replace(" ", "")  # Remove spaces from the string
    return s == s[::-1]  # Compare the string with its reverse

# Take user input
user_input = input("Enter a string: ")

if is_palindrome(user_input):
    print("The input string is a palindrome.")
else:
    print("The input string is not a palindrome.")


# In[13]:


# 1. Create a class named ‘Super’ and inside that class define a user-defined
# function named fun1
# a. Inside the ‘fun1’ function, pass the message “This is function 1 in the
# Super class.” in the print statement.


# In[14]:


class Super:
    def fun1(self):
        print("This is function 1 in the Super class")
        
Object = Super()
Object.fun1()


# In[15]:


# 2. Create another class named ‘Modified_Super’ and inherit this class from
# the Super class
# a. Inside the Modified_Super class, create a function named ‘fun1’ and
# pass the following message inside the print statement: ‘This is function 1 in
# the Modified Super class.’
# b. Create another user-defined function named ‘fun2’ and pass the
# message: ‘This is the 2 nd function from the Modified Super class’ in the
# print statement.
# c. After that, now create an object for the Modified_Super class and call the
# fun1().


# In[16]:


class Super:
    def fun1(self):
        print("This is function 1 in the Super class")

class Modiefied_Super(Super):
    def fun1(self):
        print("This is function 1 in Modiefied_Super class")
        
    def fun2(self):
        print("This is 2nd function from the Modiefied_Super class")
        
Modiefied = Modiefied_Super()
Modiefied.fun1()


# In[17]:


# Create 2 methods named ‘Hello’. In the 1st Hello method, pass only one
# argument and pass this message: ‘This function is only having 1
# argument’. And in the 2nd Hello method, pass two arguments and pass
# this message: ‘This function is having 2 arguments’.
# a. Try to call both the methods and analyze the output of both the methods.


# In[18]:


class MyClass:
    def HelloOneArg(self, arg1):
        print("This function is only having 1 argument. Argument:", arg1)

    def HelloTwoArgs(self, arg1, arg2):
        print("This function is having 2 arguments. Arguments:", arg1, arg2)

# Creating an instance of MyClass
obj = MyClass()

# Calling the Hello methods
obj.HelloOneArg("Argument 1")
obj.HelloTwoArgs("Argument 1", "Argument 2")


# In[19]:


# 4. Create a method named ‘Sum’ that can accept multiple user inputs. Now
# add those user defined input values using for loop and the function should
# return the addition of the numbers.


# In[20]:


class Calculator:
    def Sum(self, *args):
        total = 0
        for num in args:
            total += num
        return total

# Creating an instance of Calculator class
calculator = Calculator()

# Taking user inputs
num1 = float(input("Enter a number: "))
num2 = float(input("Enter another number: "))
num3 = float(input("Enter one more number: "))

# Calling the Sum method with user inputs
result = calculator.Sum(num1, num2, num3)

print("The sum of the numbers is:", result)


# In[21]:


# 5. Create a class named ‘Encapsulation’:
# a. Inside the class, first create a constructor. Inside the constructor,
# initialize originalValue variable as 10.
# b. After creating the constructor, define a function named ‘Value’ and this
# function should return the variable that we have initialized in the
# constructor.
# c. Now create a 2nd function named setValue, and pass an argument
# named ‘newValue’. The task of this function will be to replace the value of
# the originalValue variable by the value of newValue variable.


# In[22]:


class Encapsulation:
    def __init__(self):
        self.originalValue = 10

    def Value(self):
        return self.originalValue

    def setValue(self, newValue):
        self.originalValue = newValue

# Creating an instance of Encapsulation class
encapsulation_obj = Encapsulation()

# Calling Value method to get the original value
original_val = encapsulation_obj.Value()
print("Original Value:", original_val)

# Calling setValue method to change the value
new_value = 20
encapsulation_obj.setValue(new_value)

# Calling Value method again to get the updated value
updated_val = encapsulation_obj.Value()
print("Updated Value:", updated_val)


# In[23]:


# 1. Create a Python file named Module:
# a. Inside the file, define 4 methods named – addition, subtraction,
# multiplication, and division.
# b. Each method should only accept 2 arguments and should return the
# result of operation performed in each method. For e.g., addition() should
# return the sum of two arguments.
# c. Save the Module file in .py format


# In[24]:


import Module


# In[25]:


# 2. Open a new python file and import the Module.py file
# a. Now call the 4 methods from the Module.py file, i.e., addition(),
# subtraction(), multiplication(),division().


# In[26]:


# # main.py
import Module

# Calling the methods from Module.py
result_addition = Module.addition(5, 3)
print("Addition:", result_addition)

result_subtraction = Module.subtraction(10, 4)
print("Subtraction:", result_subtraction)

result_multiplication = Module.multiplication(6, 7)
print("Multiplication:", result_multiplication)

result_division = Module.division(15, 3)
print("Division:", result_division)


# In[27]:


# 3. From the Module file, import only the addition() and pass the arguments so
# that it can display the result from the method.


# In[28]:


from Module import addition


# In[29]:


result = addition(8,4)


# In[30]:


result


# In[31]:


#  From the Module file, import only the subtraction() and pass the arguments
# so that it can display the result from the method.


# In[32]:


# main.py
from Module import subtraction

# Calling the subtraction method from Module.py
result = subtraction(10, 3)
print("Subtraction Result:", result)


# In[33]:


# 5. From the Module file, import both the multiplication() and division() and
# pass the arguments so that it can display the result from the methods.


# In[34]:


# main.py
from Module import multiplication, division

# Calling the multiplication method from Module.py
result_mul = multiplication(5, 6)
print("Multiplication Result:", result_mul)

# Calling the division method from Module.py
result_div = division(15, 3)
print("Division Result:", result_div)


# In[35]:


# 1. Create a class named parent_Class and inside the class, initialize a global
# variable num as 10
# a. Create another class named child_Class and this class should be
# inherited from the parent class.
# b. Now create an object for the child_Class and with the help of
# child_Class object, display the value of ‘nu


# In[36]:


class parent_Class:
    def __init__(self):
        global num
        num = 10

class child_Class(parent_Class):
    pass

# Creating an object of child_Class
child_obj = child_Class()

# Displaying the value of the global variable 'num'
print("Value of num from child_Class object:", num)


# In[37]:


# 2. Create three classes named A, B and C
# a. Inside the A class, create a constructor. Inside the constructor, initialize
# 2 global variables name and age.
# b. After initializing the global variables inside the constructor, now create a
# function named ‘details’ and that function should return the ‘name’ variable.
# c. Inside the B class, create a constructor. Inside the constructor, initialize 2
# global variables name and id.
# d. After initializing the global variables inside the constructor, now create a
# function named ‘details’ and that function should return the ‘name’ variable.
# e. The C class should inherit from class A, and B. Inside the class C,
# create a constructor, and inside the constructor, call the constructor of
# class A.
# f. Now, create a method inside the class C, as get_details, and this function
# should return the value of name.
# g. Atlast, create an object of class C, and with the help of the object, call
# the get_details


# In[38]:


class A:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def details(self):
        return self.name

class B:
    def __init__(self, name, id):
        self.name = name
        self.id = id

    def details(self):
        return self.name

class C(A, B):
    def __init__(self, name, age, id):
        A.__init__(self, name, age)
        B.__init__(self, name, id)

    def get_details(self):
        return self.name

# Creating an object of class C
c_obj = C("Alice", 25, "12345")

# Calling the get_details method to retrieve the name
name_from_c = c_obj.get_details()
print("Name from class C object:", name_from_c)


# In[39]:


# Create a class named ‘Sub1’, inside the class, generate a user defined
# function named ‘first’ and inside the function, pass the following statement
# in the print()- ‘This is the first function from Sub 1 class’.
# a. Now create another class named ‘Sub2’, and inside the class, create a
# function named ‘second’, and pass the following message in the print()-
# ‘This is the second function from the Sub 2 class’.
# b. After that, create another class named ‘Super’ and inside that class,
# create a method named ‘final’, and pass the below message in the print()-
# ‘This is the final method from the super class’.
# c. Now, create an object for the Super class and call all the 3 user defined
# methods, i.e., first(), second(), and final().


# In[40]:


class Sub1:
    def first(self):
        print("This is the first function from Sub 1 class")

class Sub2:
    def second(self):
        print("This is the second function from the Sub 2 class")

class Super:
    def final(self):
        print("This is the final method from the super class")

# Creating an object for the Super class
super_instance = Super()

# Calling the user-defined methods from each class
super_instance.final()  # Call the final method from the Super class
sub1_instance = Sub1()
sub1_instance.first()  # Call the first method from Sub1 class
sub2_instance = Sub2()
sub2_instance.second()  # Call the second method from Sub2 class


# In[41]:


# Create a class named ‘Parent’, and inside the class, create a function
# named ‘fun1’ and pass the following message in the print()- ‘This is the
# message from the fun1’.
# a. Now create a class named ‘Child1’ and inside the class, create a
# method named ‘fun2’ and pass the following message in the print()- ‘This is
# the message from the fun2’.
# b. After that, create another class named ‘Child2’ and inside the class,
# create a method named ‘fun3’ and pass the following message in the
# print()- ‘This is the message from the fun3’.
# c. Now, create an object of Child2 class and with the help of the object, call
# the ‘fun1’ method from the ‘Parent’ class.


# In[42]:


class Parent:
    def fun1(self):
        print("This is the message from the fun1")

class Child1:
    def fun2(self):
        print("This is the message from the fun2")

class Child2(Parent):
    def fun3(self):
        print("This is the message from the fun3")

# Creating an object of Child2 class
child2_instance = Child2()

# Calling the fun1 method from the Parent class using the Child2 object
child2_instance.fun1()


# In[43]:


# 5. Create a class named ‘Parent’, and inside the class, create a function
# named ‘fun1’ and pass the following message in the print()- ‘This is the
# message from the fun1’.
# a. Now create a class named ‘Child’ and inside the class, create a method
# named ‘fun2’ and pass the following message in the print()- ‘This is the
# message from the fun2’.
# b. After that, create another class named ‘Hybrid’ and inside the class,
# create a method named ‘fun3’ and pass the following message in the
# print()- ‘This is the message from the fun3’.
# c. Now create an object of Hybrid class and with the help of the object, call
# the ‘fun1’, ‘fun2’ and ‘fun3’ methods.


# In[44]:


class Parent:
    def fun1(self):
        print("This is the message from the fun1")

class Child(Parent):
    def fun2(self):
        print("This is the message from the fun2")

class Hybrid(Child):
    def fun3(self):
        print("This is the message from the fun3")

# Creating an object of Hybrid class
hybrid_instance = Hybrid()

# Calling the methods using the object
hybrid_instance.fun1()
hybrid_instance.fun2()
hybrid_instance.fun3()


# In[ ]:




