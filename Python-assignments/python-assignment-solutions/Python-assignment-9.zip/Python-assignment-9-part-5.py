#!/usr/bin/env python
# coding: utf-8

# In[1]:


# You work in XYZ Company as a Python. The company officials want you to write
# code for Association Rule Mining.
# Dataset: retail_dataset.csv
# Tasks To Be Performed:
# 1. Using pandas import the dataset as DataFrame
# 2. Install the mixtend library to use Apriori and association rule mining
# 3. Using the Apriori algorithm generate a list of items frequently bought together
# 4. Generate the association rules for the given items from the Apriori algorithm.


# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[4]:


data = pd.read_csv(r'C:\Users\DELL\Downloads\Retail.csv' , encoding='latin1')


# In[6]:


data.head()


# In[10]:


data.shape


# In[7]:


# 2. Install the mixtend library to use Apriori and association rule mining


# In[8]:


get_ipython().system('pip install mlxtend')


# In[9]:


from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


# In[11]:


# 3. Using the Apriori algorithm generate a list of items frequently bought together


# In[13]:


frequent_itemsets = apriori(data, min_support=0.1, use_colnames=True)


# In[14]:


rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.0)

# Display the frequent itemsets and association rules
print("Frequent Itemsets:")
print(frequent_itemsets)

print("\nAssociation Rules:")
print(rules)


# In[ ]:




