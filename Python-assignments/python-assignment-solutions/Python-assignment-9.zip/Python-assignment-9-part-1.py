#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


# Tasks To Be Performed:
# 1. K-Means Clustering:
# ● Load customer data
# ● Check the number of cells in each column with null values
# ● Create a scatter plot with Age as X and Spending Score as Y
# ● Draw a scatter plot displaying data points colored on the basis of clusters


# In[3]:


data = pd.read_csv(r'C:\Users\DELL\Downloads\customers-1.csv')


# In[4]:


data.head()


# In[5]:


data.shape


# In[6]:


data.info()


# In[7]:


# ● Check the number of cells in each column with null values

data.isna().sum()   # no null values are in data set


# In[8]:


# ● Create a scatter plot with Age as X and Spending Score as Y


# In[9]:


sns.scatterplot(data = data , x = 'Age' , y = 'Spending Score (1-100)')
plt.title('scatter plot between age vs spending score')


# In[10]:


# ● Draw a scatter plot displaying data points colored on the basis of clusters.


# In[11]:


# to draw a scatter plot we first need to find the number of clusters in given data set.


# In[12]:


# first we nned to convert all the data type into numeric right now we have gender column which is in object type


# In[13]:


data['Gender'] = data['Gender'].map({'Female' : 0 , 'Male' : 1})


# In[14]:


data.info()


# In[15]:


# before implemaenting the kmeans we will first have to impliment the standardization


# In[16]:


from sklearn.preprocessing import StandardScaler


# In[17]:


scaler = StandardScaler()


# In[18]:


data1_scaled = scaler.fit_transform(data)


# In[19]:


data1_scaled


# In[20]:


data.columns


# In[21]:


data2 = pd.DataFrame(data1_scaled , columns = ['CustomerID', 'Gender', 'Age', 'Annual Income (k$)',
       'Spending Score (1-100)'])


# In[22]:


data2.head()


# In[23]:


data2.info()


# In[24]:


# now we can implemet the kMeans algoritham to find number of clusters


# In[25]:


from sklearn.cluster import KMeans


# # elbow curved method to find the number of clusters

# In[26]:


ssd = []
clusters = list(range(2,8))
for num_clusters in clusters:
    model_clus = KMeans(n_clusters = num_clusters)
    model_clus.fit(data2)
    ssd.append(model_clus.inertia_)


# In[27]:


plt.plot(clusters , ssd)


# In[28]:


# sharpest bend is at 4 so number of clusters is 4


# In[29]:


cluster = KMeans(n_clusters = 4)
cluster.fit(data2)


# In[30]:


cluster.labels_


# In[31]:


data['ClusterID'] = cluster.labels_


# In[32]:


data.head()


# In[33]:


# ● Draw a scatter plot displaying data points colored on the basis of clusters


# In[34]:


plt.figure(figsize = (10,6))
plt.scatter(data['Age'] , data['Spending Score (1-100)'] , c = data['ClusterID'] , cmap = 'rainbow')
plt.title('K-Means clustering')
plt.xlabel('Age')
plt.ylabel('Spending Score')
plt.show()


# In[ ]:




