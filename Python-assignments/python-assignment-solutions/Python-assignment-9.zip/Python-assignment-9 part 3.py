#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Problem Statement:
# You work in XYZ Company as a Python Developer. The company officials want
# you to write code for an Agglomerative Clustering Problem.
# Tasks To Be Performed:
# 1. Load iris data from load_iris function from sklearn.datasets package
# 2. From the dataset extract the data property
# 3. Train an Agglomerative Clustering model based on the data
# 4. Plot dendrogram to visualize the clustering linkage


# In[2]:


import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt


# In[3]:


from sklearn import datasets


# In[4]:


from sklearn.datasets import load_iris


# In[5]:


iris = load_iris()


# In[6]:


# 2. From the dataset extract the data property


# In[7]:


data = iris.data


# In[8]:


data.shape


# In[9]:


# 3. Train an Agglomerative Clustering model based on the data


# In[10]:


from sklearn.cluster import AgglomerativeClustering


# In[11]:


agg_clustering = AgglomerativeClustering(n_clusters=3)
agg_clustering.fit(data)


# In[12]:


# 4. Plot dendrogram to visualize the clustering linkage


# In[13]:


from scipy.cluster.hierarchy import dendrogram, linkage


# In[14]:


linkage_matrix = linkage(data, method='ward')


# In[15]:


linkage_matrix


# In[16]:


# plotting the dendogram


# In[17]:


plt.figure(figsize=(10, 7))
dendrogram(linkage_matrix)
plt.title('Dendrogram')
plt.xlabel('Samples')
plt.ylabel('Distance')
plt.show()


# In[ ]:




