#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Tasks To Be Performed:
# 1. K-Means Clustering:
# ● Load customer data
# ● Check the number of cells in each column with null values
# ● Create a scatter plot with Age as X and Spending Score as Y
# ● Find out the best number for clusters between 1 and 10 (inclusive) using the elbow method
# ● Draw a scatter plot displaying data points colored on the basis of clusters.


# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


data = pd.read_csv(r'C:\Users\DELL\Downloads\customers-1.csv')


# In[4]:


data.head()


# In[5]:


data.shape


# In[6]:


data.info()


# In[7]:


# ● Check the number of cells in each column with null values


# In[8]:


data.isnull().sum()


# In[9]:


# ● Create a scatter plot with Age as X and Spending Score as Y


# In[10]:


sns.scatterplot(data = data , x = 'Age' , y = 'Spending Score (1-100)',cmap = 'blue')


# In[11]:


# ● Find out the best number for clusters between 1 and 10 (inclusive) using the elbow method


# In[12]:


data.info()


# In[13]:


data['Gender'] = data['Gender'].map({'Female' : 0 , 'Male' : 1})


# In[14]:


data.info()


# In[15]:


from sklearn.preprocessing import StandardScaler


# In[16]:


scaler = StandardScaler()


# In[17]:


data1_scaled = scaler.fit_transform(data)


# In[18]:


data1_scaled


# In[19]:


data.columns


# In[20]:


data2 = pd.DataFrame( data1_scaled , columns = ['CustomerID', 'Gender', 'Age', 'Annual Income (k$)',
       'Spending Score (1-100)'])


# In[21]:


data2.head()


# In[22]:


data2.info()


# In[23]:


from sklearn.cluster import KMeans


# In[24]:


ssd = []
clusters = list(range(1,11))
for num_clusters in clusters:
    model_clus = KMeans(n_clusters = num_clusters)
    model_clus.fit(data2)
    ssd.append(model_clus.inertia_)


# In[25]:


plt.plot(clusters,ssd)


# In[26]:


# sharpest bend is at 2 and 4 here we are taking 4 cluster


# In[27]:


# ● Draw a scatter plot displaying data points colored on the basis of clusters.


# In[28]:


cluster = KMeans(n_clusters = 4)
cluster.fit(data2)


# In[29]:


cluster.labels_


# In[30]:


data['ClusterID'] = cluster.labels_


# In[31]:


data.head()


# In[32]:


plt.figure(figsize = (10,4))
plt.scatter(data['Age'] , data['Spending Score (1-100)'] , c = data['ClusterID'] , cmap = 'Blues')
plt.title('K-Means clustering')
plt.xlabel('Age')
plt.ylabel('Spending Score')
plt.show()


# In[ ]:




