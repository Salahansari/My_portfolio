#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Problem Statement:
# You work in XYZ Company as a Python developer. The company officials want
# you to write code for an Agglomerative Clustering Problem.
# Data:
# [[5,3],
# [10,15],
# [15,12],
# [24,10],
# [30,30],
# [85,70],
# [71,80],
# [60,78],
# [70,55],
# [80,91],]
# Tasks To Be Performed:
# 1. Using the np.array function create an np array from the data given above
# 2. Generate a scatter plot for the data
# 3. Plot dendrogram to visualize the clustering linkage


# In[2]:


import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage


# In[3]:


# 1. Using the np.array function create an np array from the data given above


# In[4]:


data = np.array([[5,3],[10,15],[15,12],[24,10],[30,30],[85,70],[71,80],[60,78],[70,55],[80,91]])


# In[5]:


data.shape


# In[6]:


# 2. Generate a scatter plot for the data.


# In[7]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[8]:


plt.figure(figsize=(8, 6))
plt.scatter(data[:, 0], data[:, 1])
plt.title('Scatter Plot of Data')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.grid(True)
plt.show()


# In[ ]:


# 3. Plot dendrogram to visualize the clustering linkage


# In[9]:


linkage_matrix = linkage(data, method='ward')

plt.figure(figsize=(10, 7))
dendrogram(linkage_matrix)
plt.title('Dendrogram')
plt.xlabel('Data Points')
plt.ylabel('Distance')
plt.show()


# In[ ]:




