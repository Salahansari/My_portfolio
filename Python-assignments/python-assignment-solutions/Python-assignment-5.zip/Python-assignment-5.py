#!/usr/bin/env python
# coding: utf-8

# # Pandas-assignment-1

# In[1]:


import pandas as pd


# In[2]:


# 1. Start off by importing the customer_churn.csv file in the jupyter notebook
# and store that in churn DataFrame.


# In[3]:


churn_DataFrame = pd.read_csv("customer_churn.csv")


# In[4]:


churn_DataFrame.head()


# In[5]:


# 2. From the churn DataFrame, select only 3rd, 7th, 9th, and 20th columns
# and all the rows and store that in a new DataFrame named newCols.


# In[6]:


newCols = churn_DataFrame[['SeniorCitizen','PhoneService','InternetService','TotalCharges']]


# In[7]:


newCols.head()


# In[8]:


# 3. From the original DataFrame, select only the rows from the 200th index till
# the 1000th index(inclusive) column.


# In[9]:


churn_DataFrame[200:1001]


# In[10]:


# 4. Now select the rows from 20th index till 200th index(exclusive),and
# columns from 2nd index till 15th index value.


# In[11]:


selected_rows = churn_DataFrame.iloc[20:200, : ]


# In[12]:


selected_columns = selected_rows.iloc[ : , 2:15]


# In[13]:


selected_columns.head()


# In[14]:


# 5. Display the top 100 records from the original DataFrame.


# In[15]:


pd.options.display.max_rows = 100
churn_DataFrame.head(100)


# In[16]:


# 6. Display the last 10 records from the DataFrame.


# In[17]:


churn_DataFrame.tail(10)


# In[18]:


# 7. Display the last record from the DataFrame.


# In[19]:


churn_DataFrame.tail(1)


# In[20]:


# 8. Now from the churn DataFrame, try to sort the data by the tenure column
# according to the descending order.


# In[21]:


churn_DataFrame.sort_values(by = 'tenure' , ascending = False)


# In[22]:


# 9. Fetch all the records that are satisfying the following condition:
# a. Tenure>50 and the gender as ‘Female’
# b. Gender as ‘Male’ and SeniorCitizen as 0
# c. TechSupport as ‘Yes’ and Churn as ‘No’
# d. Contract type as ‘Month-to-month’ and Churn as ‘Yes’


# In[23]:


churn_DataFrame[(churn_DataFrame['tenure'] > 50) & (churn_DataFrame['gender']=='Female')]


# In[24]:


# b. Gender as ‘Male’ and SeniorCitizen as 0


# In[25]:


churn_DataFrame[(churn_DataFrame['gender']== 'Male') & (churn_DataFrame['SeniorCitizen']==0)]


# In[26]:


# c. TechSupport as ‘Yes’ and Churn as ‘No’


# In[27]:


churn_DataFrame[(churn_DataFrame['TechSupport']=='Yes') & (churn_DataFrame['Churn']=='No')]


# In[28]:


# d. Contract type as ‘Month-to-month’ and Churn as ‘Yes’


# In[30]:


churn_DataFrame[(churn_DataFrame['Contract']=='Month-to-Month') & (churn_DataFrame['Churn']=='Yes')]


# In[32]:


# 10. Use a for loop to calculate the number of customers that are getting the
# tech support and are male senior citizens.


# In[46]:


count_male_senior_tech_support = 0
for val in churn_DataFrame:
    if (val['TechSupport']=='yes') and (val['gender']=='Male') and (val['SeniorCitizen']== 1):
        count_male_senior_tech_support += 1
    
print(count_male_senior_tech_support)


# In[47]:


count = 0

# Iterate through the customer data
for val in churn_DataFrame:
    # Check if the customer is a male senior citizen (age >= 65 and gender is 'Male') and has tech support
    if val['gender'] == 'Male' and val['SeniorCitizen'] == 1 and val['tech_support']:
        count += 1

# Print the result
print("Number of male senior citizens with tech support:", count)


# In[ ]:




