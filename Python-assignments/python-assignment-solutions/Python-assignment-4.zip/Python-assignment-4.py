#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Create a list named ‘myList’ that has the following elements: 10, 20, 30,
# ‘apple’, True, 8.10:
# a. Now in the ‘myList’, append these values: 30, 40
# b. After that, reverse the elements of the ‘myList’ and store that in
# ‘reversedList’


# In[2]:


myList = [10,20,30,'apple',True,8.10]


# In[3]:


myList.append(30)


# In[4]:


myList.append(40)


# In[5]:


myList


# In[6]:


reversedList = myList.reverse()


# In[7]:


myList


# In[8]:


myList = [10,20,30,'apple',True,8.10 , 30 , 40]


# In[9]:


reversedList = myList[: :  -1]


# In[10]:


reversedList


# In[11]:


# 2. Create a dictionary with key values as 1, 2, 3 and the values as ‘data’,
# ‘information’ and ‘text’:
# a. After that, eliminate the ‘text’ value from the dictionary
# b. Add ‘features’ in the dictionary
# c. Fetch the ‘data’ element from the dictionary and display it in the output


# In[12]:


dic = {1 : 'data',
       2 : 'information',
       3 : 'text'}


# In[13]:


dic


# In[14]:


dic.popitem()


# In[15]:


dic


# In[16]:


dic[4] = 'featurs'


# In[17]:


dic


# In[18]:


dic.get(1)


# In[19]:


# 3. Create a tuple and add these elements 1, 2, 3, apple, mango in my_tuple.


# In[20]:


my_tuple = (1,2,3,'apple','mango')


# In[21]:


my_tuple


# In[22]:


# 4. Create another tuple named numeric_tuple consisting of only integer
# values 10, 20, 30, 40, 50:
# a. Find the minimum value from the numeric_tuple
# b. Concatenate my_tuple with numeric_tuple and store the result in r1
# c. Duplicate the tuple named my_tuple 2 times and store that in ‘newdupli’


# In[23]:


numeric_tuple = (10,20,30,40,50)


# In[24]:


min_numeric_tuple = min(numeric_tuple)


# In[25]:


min_numeric_tuple


# In[26]:


concanited_tuple = my_tuple + numeric_tuple
print("concatinated tuple :" ,concanited_tuple )


# In[27]:


newdupli = my_tuple * 2
print(" Duplicated_tuple : ", newdupli)


# In[28]:


# 5. Create 2 sets with the names set1 and set2, where set1 contains
# {1,2,3,4,5} and set2 contains {2,3,7,6,1}
# Perform the below operation:
# a. set1 union set2
# b. set1 intersection set2
# c. set1 difference set2


# In[29]:


set1 = {1,2,3,4,5}
set2 = {2,3,7,6,1}


# In[30]:


set1.union(set2)


# In[31]:


set1.intersection(set2)


# In[32]:


set1.difference(set2)


#  # Numpy assignment

# In[33]:


# 1. Create a 3x3 matrix array with values ranging from 2 to 10.


# In[34]:


import numpy as np


# In[39]:


A = np.arange(2,11)


# In[40]:


A


# In[41]:


A.reshape(3,3)


# In[42]:


# 2. Create a NumPy array having user input values and convert the integer
# type to the float type of the elements of the array. For instance: Original
# array [1, 2, 3, 4] Array converted to a float type: [ 1. 2. 3. 4.]


# In[44]:


A = np.array([1,2,3,4])


# In[45]:


A


# In[46]:


A.astype(float)


# In[48]:


# 3. Write a NumPy program to append values to the end of an array. For
# instance: Original array: [10, 20, 30] . After that, append values to the end
# of the array: [10 20 30 40 50 60 70 80 90]


# In[50]:


original_array = np.array([10,20,30])
appended_array = np.array([40,50,60,70,80,90])


# In[51]:


original_appended_array = np.append(original_array , appended_array)
print(original_appended_array)


# In[52]:


# Create two NumPy arrays and add the elements of both the arrays and
# store the result in sumArray


# In[53]:


A = np.array([1,2,3,4,5,6])
B = np.array([10,20,30,40,50,60])
A,B


# In[56]:


sumArray = np.add(A,B)


# In[57]:


sumArray


# In[64]:


sumArray = []
for i in range(len(A)):
    sum_element = A[i] +B[i]
    sumArray.append(sum_element)


# In[65]:


sumArray


# In[66]:


# 5. Create a 3x3 array having values from 10-90 (interval of 10) and store that
# in array1
# Perform the following tasks:
# a. Extract the 1st row from the array
# b. Extract the last element from the array


# In[67]:


array1 = np.arange(10,91,10).reshape(3,3)


# In[68]:


array1


# In[70]:


array1[0:1,0:3]


# In[71]:


array1[2:3,2:3]


# In[ ]:




